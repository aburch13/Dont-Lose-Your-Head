This font is free for personal, non-commercial use only. Please contact me if you plan to use it for other purposes.

If this font is redistributed, please give me credit, and provide a link to my webpage.

Please don't distribute this without this read-me file, or offer it on a CD for commercial purposes without contacting me first.

Enjoy the font!
Su Lucas

Website: http://www.sulucas.net
e-mail: fonts@highveldmail.co.za


